#include <stdio.h>

int main()
{
	int i=0;

	while(!i){
	}
	printf("I am exiting from func\n");
	return 0;
}
