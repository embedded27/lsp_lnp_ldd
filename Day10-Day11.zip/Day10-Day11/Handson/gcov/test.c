#include <stdio.h>
extern int libfn1();

int main ()
{
     libfn1();
     libfn2(15);
     libfn2(5);
}
