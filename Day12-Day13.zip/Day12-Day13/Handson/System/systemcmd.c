#include<stdio.h>
#include<stdlib.h>

int main()
{
	system("cat ");
	return 0;
}
