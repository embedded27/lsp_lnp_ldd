//Detecting unitialized variable
#include <stdio.h>

int main()
{
    //int x;
    //working
    int x=0;
    if(x == 0)
    {
        printf("X is zero"); /* replace with cout and include 
                                iostream for C++ */
    }
    return 0;
}
